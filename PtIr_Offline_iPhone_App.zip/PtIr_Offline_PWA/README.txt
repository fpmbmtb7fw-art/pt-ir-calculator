Pt Ir Calculator PWA

Deployment (free GitHub Pages):
1. Create a GitHub repository, e.g. ptir-calculator.
2. Upload index.html, manifest.webmanifest, sw.js, icon-192.png and icon-512.png to the repository root.
3. In repository Settings > Pages, select Deploy from a branch, main / (root), then Save.
4. Wait for the HTTPS GitHub Pages URL to be available.
5. Open that HTTPS URL in Safari on iPhone, choose Share > Add to Home Screen > Add.
6. Launch the installed icon once while online, then use offline.

Important: A local HTML file opened in Files is NOT an installable PWA. HTTPS hosting is required for the service worker. History is stored only in the installed app's local storage; deleting app/site data can erase it. No account or server is used.
